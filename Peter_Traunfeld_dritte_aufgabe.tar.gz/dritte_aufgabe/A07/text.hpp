#ifndef TEXT_HPP
#define TEXT_HPP

#include <string>

std::string str1 = "Blaukraut bleibt Blaukraut und Brautkleid bleibt Brautkleid.";
std::string str2 = "Am Anfang wurde das Universum erschaffen. Das machte viele Leute sehr wuetend und wurde allenthalben als Schritt in die falsche Richtung angesehen.";
std::string str3 = "Habe nun, ach! Philosophie, Juristerei und Medizin, Und leider auch Theologie Durchaus studiert, mit heissem Bemuehn. Da steh ich nun, ich armer Tor! Und bin so klug als wie zuvor.";

#endif
