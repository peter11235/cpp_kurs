#ifndef EASTER_H
#define EASTER_H

#include "date.hpp"
Date easter(int y);

#endif
