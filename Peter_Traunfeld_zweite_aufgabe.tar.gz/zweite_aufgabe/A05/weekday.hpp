#ifndef WEEKDAY_H
#define WEEKDAY_H

#include "date.hpp"

std::string weekday(Date d);

#endif
