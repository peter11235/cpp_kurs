#ifndef EMAIL_H
#define EMAIL_H
bool is_email(std::string s);
#endif
