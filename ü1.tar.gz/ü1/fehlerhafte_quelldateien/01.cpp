#include <iostream>
int main()
{
    int y = 2015;
    int d = 5;
    std::cout << "Im Jahr  " << y << " ist Ostern am " << d << ". April." << std::endl;
    return 0;
}
