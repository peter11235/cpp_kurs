#include <iostream>
int main() 
    float var = 10.5;
    int div = -1;
    std::cout << "Das Produkt der Zahlen ist " << var*div << "." << std::endl;
}
