#include <iostream>
int main()
{
    std::cout << "Geben Sie eine Zahl ein." << std::endl;
    int x;
    std::cin >> x;
    std::cout "Geben Sie noch eine Zahl ein." << std::endl;
    int y;
    std::cin >> y;
    std::cout << "Das Produkt der Zahlen ist " << x * y << "." << std::endl;
    return 0;
}
