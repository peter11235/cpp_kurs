#include <iostream>
int main()
{
    cout << "Hello, World!\n";
    return 0;
}
