#include <iostream>
int main() {
    std::cout << "Geben Sie eine Zahl ein." << std::endl;
    int x;
    std::cin >> X;
    std::cout << "Es wurde " << x << " eingegeben." << std::endl;
    return 0;
}
