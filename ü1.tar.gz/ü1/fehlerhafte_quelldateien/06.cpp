int main() {
    int x = 10;
    int y = 2;
    int z = x / y;
    std::cout << x << " geteilt durch " << y << " ist " << z << "." << std::endl;
    return 0;
}
